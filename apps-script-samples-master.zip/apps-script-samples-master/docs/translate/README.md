# Translate

Translate is a sample script for Google Docs that allows you to translate
selected text from a set of source languages to a set of destination languages.
The resulting translation can then be inserted back into the Google Document.
This sample was originally designed as a
[quickstart](https://developers.google.com/apps-script/quickstart/docs).

![Google Docs Translate Quickstart](https://developers.google.com/apps-script/images/quickstart-translate.png)
