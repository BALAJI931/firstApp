# Google Docs Add-ons

## Cursor Inspector

This add-on allows you to inspect the current state of the cursor or selection within a document. The information is presented in a sidebar and updates automatically every few seconds.

## Translate

This add-on allows you to translate selected text from a set of source languages to a set of destination languages.
