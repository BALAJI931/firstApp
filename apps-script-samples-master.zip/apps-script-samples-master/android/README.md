# Apps Scripts for Android

## [Converting Android Apps into Android Add-ons](https://developers.google.com/apps-script/add-ons/mobile/android)

This sample describes how to convert an existing Android app into an Android add-on.

## Mobile Doc Translate Add-on

A sample Google Apps Script mobile add-on for Google Docs.
