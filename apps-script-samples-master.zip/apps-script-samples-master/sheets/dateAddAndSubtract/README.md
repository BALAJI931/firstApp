# Date Add and Subtract

Date Add and Subtract is a sample
[add-on for Google Sheets](https://developers.google.com/apps-script/add-ons)
that provides custom functions for date manipulation. The script uses the
[Moment.js](http://momentjs.com/) JavaScript library, which is included directly
in the Apps Script project.

![Date Add and Subtract screenshot](screenshot.png)

## Try it out

For your convience we have published the script to the Google Sheets
[add-ons store](https://chrome.google.com/webstore/detail/date-add-and-subtract/mhdmhddjinipgjhpicaidhpimlmgnflb).
Install the add-on via the store and follow the instructions to get started.
