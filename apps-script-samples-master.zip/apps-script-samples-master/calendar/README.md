# Apps Scripts for Google Calendar

## [Vacation Calendar](https://developers.google.com/apps-script/articles/vacation-calendar)

This tutorial allows a user in a domain to automatically populate a team vacation calendar.
